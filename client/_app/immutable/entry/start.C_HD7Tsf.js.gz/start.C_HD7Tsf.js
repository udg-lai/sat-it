import{a as t}from"../chunks/Bu8BVEvf.js";export{t as start};
